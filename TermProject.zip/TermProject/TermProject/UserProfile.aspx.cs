﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class UserProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            use.InnerHtml = Convert.ToString(Session["user"]);
           // um.InnerHtml = Convert.ToStri(Session["user"]);
        }


        protected void Button1_Click1(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Home.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateBlog.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("Stats.aspx");
            
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("Check_comment.aspx");
        }
    }
}