﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class Check_comment : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Coment tb = new Coment();
        protected void Page_Load(object sender, EventArgs e)
        {
            use.InnerHtml = Convert.ToString(Session["user"]);
            var row = from r in db.Coments
                      where r.user == Convert.ToString(Session["user"])
                      select r;
            if (row.Count() > 0)
            {
                var t = "<table border=1>";
                t += "<tr>";
                t += "<td><strong>Comment</strong></td><td><strong>Writer</strong></td><td><strong>Blog</strong></td>";
                t += "</tr>";
                foreach (var r in row)
                {
                    const string quote = "\"";
                    t += "<tr>";
                    t += "<td>" + r.Comment + "</td><td><a>" + r.comment_write + "</a></td><td>" + r.Title + "</td>";
                    t += "</tr>";
                }
                t += "</table>";
                error.InnerHtml += t;
            }
            else
            {
                error.InnerHtml = "No Data Found";
            }
        }
         protected void Button2_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Home.aspx");
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserProfile.aspx");
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}