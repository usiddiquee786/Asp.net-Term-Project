﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;

namespace TermProject
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Blog tb = new Blog();
        Coment tc = new Coment();
        protected void Page_Load(object sender, EventArgs e)
        {
            //Thread.Sleep(8000);
            //Response.Write(HiddenField1.Value);
        }
        protected void Button2_Load(object sender, EventArgs e)
        {
            //Response.Write(HiddenField1.Value);
            //Response.Write("Umar");
        }
        protected void HiddenField2_ValueChanged(object sender, EventArgs e)
        {
            
        }

        

        protected void Button2_Click1(object sender, EventArgs e)
        {
            if (Button2.Text == "View Details")
            {
                var row = from r in db.Blogs
                          where r.Title == Convert.ToString(HiddenField1.Value)
                          select r;
                if (row.Count() > 0)
                {
                    var t = "<table border=1>";
                    t += "<tr>";
                    t += "<td><strong>ID</strong></td><td><strong>Date</strong></td><td><strong>Writer</strong></td><td><strong>Category</strong></td><td><strong>Likes</strong></td>";
                    t += "</tr>";
                    foreach (var r in row)
                    {
                        t += "<tr>";
                        t += "<td>" + r.Id + "</td><td><a>" + r.Date + "</a></td><td>" + r.user + "</td><td>" + r.Category + "</td><td>" + r.like + "</td>";
                        t += "</tr>";
                        //Response.Write(r.Body);

                    }
                    t += "</table>";
                    info.InnerHtml = t;
                    var tt = "<table>";
                    foreach (var r in row)
                    {
                        tt += "<tr>";
                        tt += "<td>" + r.Body + "</td>";
                        tt += "</tr>";

                    }
                    tt += "</table>";
                    des.InnerHtml = tt;
                    Button2.Text = "Like";
                }
                else
                {

                    des.InnerHtml = "No Data Found" + HiddenField1.Value;

                }
                var roww = from r in db.Coments
                          where r.Title == Convert.ToString(HiddenField1.Value)
                          select r;
                if(roww.Count()>0)
                {
                    var ttt = "<table border=1>";
                    ttt += "<tr>";
                    ttt += "<td><strong>Comments</strong></td>";
                    ttt += "</tr>";
                    foreach (var r in roww)
                    {
                        ttt += "<tr>";
                        ttt += "<td>" + r.Comment + "<em>("+r.comment_write+")</em></td>";
                        ttt += "</tr>";

                    }
                    ttt += "</table>";
                    P1.InnerHtml = ttt;
                }
            }
            else if(Button2.Text=="Like")
            {
                var row = from r in db.Blogs
                          where r.Title == Convert.ToString(HiddenField1.Value)
                          select r;
                if (row.Count() > 0)
                {
                    foreach (var r in row)
                    {
                        if (r.like == null)
                        {
                            r.like = 1;
                        }
                        else
                        {
                            r.like = r.like + 1;
                        }
                    }
                }
                db.SubmitChanges();

            }

            //Response.Write(HiddenField1.Value);
        }

        protected void HiddenField1_ValueChanged(object sender, EventArgs e)
        {
           // Response.Write("Umar");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["user"]) != "")
            {
                var user = "";
                var row = from r in db.Blogs
                          where r.Title == Convert.ToString(HiddenField1.Value)
                          select r;
                if (row.Count() > 0)
                {
                    foreach (var r in row)
                    {
                        user = r.user;
                    }
                }
                tc.Comment = TextArea1.InnerText;
                tc.Title = Convert.ToString(HiddenField1.Value);
                tc.user = user;
                tc.comment_write = Convert.ToString(Session["user"]);
                db.Coments.InsertOnSubmit(tc);
                db.SubmitChanges();

                TextArea1.InnerText = "";
                err.InnerHtml = "Comment Submited Successfully..!";
            }
            else
            {
                err.InnerHtml = "Please Login First to Comment";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var row = from r in db.Blogs
                      where r.Title.Substring(0,1) =="H" 
                      select r;
            if (row.Count() > 0)
            {
                Response.Write("Umar");
                db.Blogs.DeleteAllOnSubmit(row);
                db.SubmitChanges();


            }
        }
    }
}