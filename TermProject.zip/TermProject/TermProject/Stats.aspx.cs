﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class Stats : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Blog tb = new Blog();
        protected void Page_Load(object sender, EventArgs e)
        {
            use.InnerHtml = Convert.ToString(Session["user"]);
            var row = from r in db.Blogs
                      where r.user == Convert.ToString(Session["user"])
                      select r;
            if (row.Count() > 0)
            {
                var t = "<table border=1>";
                t += "<tr>";
                t += "<td><strong>ID</strong></td><td><strong>Title</strong></td><td><strong>Writer</strong></td><td><strong>Date</strong></td><td><strong>Likes</strong></td>";
                t += "</tr>";
                foreach (var r in row)
                {
                    const string quote = "\"";
                    t += "<tr>";
                    t += "<td>" + r.Id + "</td><td><a>" + r.Title + "</a></td><td>" + r.user + "</td><td>"+r.Date+"</td><td>"+r.like+"</td>";
                    t += "</tr>";
                }
                t += "</table>";
                error.InnerHtml += t;
            }
            else
            {
                error.InnerHtml = "No Data Found";
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Home.aspx");
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserProfile.aspx");
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}