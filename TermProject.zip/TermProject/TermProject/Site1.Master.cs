﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Convert.ToString(Session["user"])!="")
            {
                Button1.Text = Convert.ToString(Session["user"]);
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Button1.Text == "Login")
            {
                Response.Redirect("login.aspx");
            }
            else if(Button1.Text==Convert.ToString(Session["user"])){
                Response.Redirect("UserProfile.aspx");

            }
        }
    }
}