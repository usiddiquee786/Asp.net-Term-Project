﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Blog tb = new Blog();
        protected void Page_Load(object sender, EventArgs e)
        {
            var row = from r in db.Blogs
                      where r.Category=="Cricket"
                      select r;
            if (row.Count() > 0)
            {
                var t = "<table border=1>";
                t += "<tr>";
                t+="<td><strong>ID</strong></td><td><strong>Title</strong></td><td><strong>Writer</strong></td><td><strong>Details</strong></td>";
                t+="</tr>";
               foreach (var r in row)
               {
                   const string quote = "\"";  
                    t+="<tr>";
                    t += "<td>" + r.Id + "</td><td><a>" + r.Title + "</a></td><td>" + r.user + "</td>";
                    t += "<td><button type=" + quote + "button" + quote + " value=\""+r.Title+"\" onclick=" + quote + " gettile(value)" + quote + "/>View More</button></td>"; 
                   t+="</tr>";
               }
               t += "</table>";
               tab.InnerHtml += t;
            }
            else
            {
                tab.InnerHtml = "NO Data Found..!";
            }
        }


        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Write("Umar Ahmad Siddiquee");
        }

    }
}