﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class CreateBlog : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Blog tb = new Blog();
        protected void Page_Load(object sender, EventArgs e)
        {
            use.InnerHtml = Convert.ToString(Session["user"]);
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Home.aspx");
        }
        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserProfile.aspx");
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            DateTime dateTime = DateTime.UtcNow.Date;
            tb.Title = TextBox1.Text;
            tb.Category = DropDownList1.Text;
            tb.Date = now;
            tb.Body = TextArea1.InnerText;
            tb.user = Convert.ToString(Session["user"]);
            db.Blogs.InsertOnSubmit(tb);
            db.SubmitChanges();
            TextBox1.Text = "";
            TextArea1.InnerText = "";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}