﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class Register : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Login tb = new Login();
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            tb.username = TextBox1.Text;
            tb.password = TextBox2.Text;
            db.Logins.InsertOnSubmit(tb);
            db.SubmitChanges();
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            ale.InnerHtml = "Congratulation you are Registered Now..!";
            //var row = from r in db.Logins
                     // where r.username == TextBox1.Text && r.password == TextBox2.Text
                      //select r;
            //Response.Write(row);
            //if (row.Count() > 0)
            //{
              //  foreach (var r in row)
                //{
                    //Response.Write(r.username);
                  //  Session["user"] = r.username;
                    //Response.Redirect("UserProfile.aspx");

//                }
  //          }
        }
    }
}