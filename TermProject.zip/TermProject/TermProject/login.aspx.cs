﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TermProject
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        Login tb = new Login();
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var row = from r in db.Logins
                      where r.username == TextBox1.Text && r.password == TextBox2.Text
                      select r;
            //Response.Write(row);
            if (row.Count() > 0)
            {
                foreach (var r in row)
                {
                    //Response.Write(r.username);
                    Session["user"] = r.username;
                    Response.Redirect("UserProfile.aspx");
                    
                }
            }
            else
            {
                ale.InnerHtml = "Inccorrct Username or Password";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}